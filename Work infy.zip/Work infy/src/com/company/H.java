package com.company;

public class H Automation


        password : automationtalkuser

        Joie_Vibre@0!9


        environment setup : https://apple.ent.box.com/folder/0


        itlinfosys\saaransh.shaw

        http:/sparshv2

        16 th and 17th aug timing
        24th and 30th aug attendance

        107587




        http://appleconnect-uat.apple.com
        https://appleconnect.apple.com/account/manage#!devices

        https://github.pie.apple.com

        https://github.pie.apple.com/RetailAppsATX/Texas


        prsid saaransh :  2700954230


        divyalakshmi_konda

        D1vy@G@l1nk1




export mySqlUrl=jdbc:mysql://mysdb-talk-dev-talkd.caojkrts49r3.us-west-2.rds.amazonaws.com:3306/talkd
        export mySqlUserName=talkd_owner
        export mySqlPassword=Mu5ica13_Tu1ar3mia_M0i5t3n


        jtalk token:

        jtalk-rest/src/main/resources/getToken.sh

        Make sure that /usr/local/bin is in your $PATH.



        -Denv=USEAST1_AWSDEV
        Teasing.xml
        Suite - src/test/resources/testng.xml


        git clone -b main https://github.pie.apple.com/reserver/TalkServiceAutomation

        Test-resources-testng.xml.    -> run








        git clone -b develop git@github.pie.apple.com:RetailAppsATX/JTalk.git

        git checkout -b rdar_88607571_Fetch_all_users

        git branch develop





        git checkout -- .

        git status

        git log

        git show

        commant + i

        replace pick with squash on all commits except 1st one
        Escape

        Shift + : wq

        add # to all commit comments

        Shift + : wq

        $ git rebase -i HEAD~3

        git status

        git push —force





        git reset --soft HEAD~2
        git commit -m "new commit message"
        git push -f








        Escape ;q!






//        if let storeURL = store.storeUrl, !storeURL.isEmpty {
//            baseURL = storeURL
//        }

        splunk production

        https://splunk-ist.corp.apple.com/en-US/app/search/search?q=search%20index%3Djtalk_walker_prod%20aws_region%3Dus-west-2%20%7C%20timechart%20span%3D1s%20%20count%20AS%20TPS%20&display.page.search.mode=fast&dispatch.sample_ratio=1&earliest=-24h%40h&latest=now&display.page.search.tab=visualizations&display.general.type=visualizations&display.events.fields=%5B%22host%22%2C%22source%22%2C%22sourcetype%22%2C%22aws_region%22%5D&sid=1657551971.126044_7B1E1EF3-C387-49CF-94E4-E1355BCB2D66



        index=jtalk_walker_prod aws_region=us-west-2 | timechart span=1s  count AS TPS | timechart span=1s max(TPS) AS Max_TPS




        Transfer files from one system to another

        scp talk@automationretailapps.corp.apple.com:~/Desktop/NewFolder.1.zip .

        scp talk@automationretailapps.corp.apple.com:~/Desktop/NewFolder.2.zip .

        scp talk@automationretailapps.corp.apple.com:~/Desktop/jmeterp.zip .







        {
}
