package com.company;

public class WebSo Web socket

        WebSocket is a communication protocol that makes it possible to establish a two-way communication channel between a server and a client.

        WebSocket works by first establishing a regular HTTP connection with the server and then upgrading it to a bidirectional websocket connection by sending an Upgrade header.

        WebSocket is supported in most modern web browsers and for browsers that don’t support it, we have libraries that provide fallbacks to other techniques like comet and long-polling.

        In the first method, we register a websocket endpoint that the clients will use to connect to our websocket server.

        Notice the use of withSockJS() with the endpoint configuration. SockJS is used to enable fallback options for browsers that don’t support websocket.

        Configuration

        implement interface WebSockerMessageBrokerConfigurer

Override - registerStompEndPoints(resister the end point-> /ws , /wss .withsockJS) and configuremessageBroker(setApplicationDestinationPrefix -> /app

        And enableSimpleMessageBroker -> /topic, )



        Model

        Message type(enum-> chat, join,leave), content, sender



        Controller

@MessageMapping("/chat.sendMessage")
@SendTo("/topic/public")
public ChatMessage sendMessage(@Payload ChatMessage chatMessage) {
        return chatMessage;
        }
@MessageMapping("/chat.addUser")
@SendTo("/topic/public")
public ChatMessage addUser(@Payload ChatMessage chatMessage,
        SimpMessageHeaderAccessor headerAccessor) {
        // Add username in web socket session
        headerAccessor.getSessionAttributes().put("username", chatMessage.getSender());
        return chatMessage;




        Web sockets security

        via ChannelInterceptor(SecurityContextChannelInterceoter) extending AbstractSecurityWebSocketMessageBrokerCinfigurer

        Testing

        1.Container Integration testing

        using TextContextFramework to load context and send messages to clientInbouundChannels

        2.End to end testing, load testing



@MessageMapping("/chat.private.{username}")
public void filterPrivateMessage(@Payload ChatMessage message, @DestinationVariable("username") String username, Principal principal) {
        checkProfanityAndSanitize(message);

        message.setUsername(principal.getName());

        simpMessagingTemplate.convertAndSend("/user/" + username + "/exchange/amq.direct/chat.message", message);
        }


        .JS
        var socket = new SockJS("/ws");
        stompClient = Stomp.over(socket);
        stompClient.connect({}, onConnected, onError)
        function onConnected() {
        // Subscribe to the Public Topic
        stompClient.subscribe('/topic/public', onMessageReceived);

        // Tell your username to the server
        stompClient.send("/app/chat.addUser",
        {},
        JSON.stringify({sender: username, type: 'JOIN'})
        )

        function sendMessage(event) {
        var messageContent = messageInput.value.trim();
        if(messageContent && stompClient) {
        var chatMessage = {
        sender: username,
        content: messageInput.value,
        type: 'CHAT'
        };
        stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
        messageInput.value = '';
        }

@MessageMapping(“/chat.private.{username}”)
Public void filterPrivateMessage(@Payload ChatMessage message, @DestinationVariable(“username”)String username, Principal principal){
        checkProfanityAndSanitize(message);
        Message.setUsername(principal.getName));
        simpleMessageTemplate.convertAndSend(“/user/“ + username + “/exchange/amq.direct/chat.message”, message);
        )

private void checkProfanityAndSanitize(ChatMessage message) {
        long profanityLevel = profanityFilter.getMessageProfanity(message.getMessage());
        profanity.increment(profanityLevel);
        message.setMessage(profanityFilter.filter(message.getMessage()));
        }

        SimpleBroker
        StompBrokerRelay


        https://docs.google.com/document/d/1Q0vcng-ExHJ3TQGmfaxGxRbRajHkWOsnkl3NN8NIZpE/edit?usp=sharing

        from Pedro Castro da Silveira to Everyone:    10:02  PM

        https://projectreactor.io







        {
}
