package com.company;

public class React {
    npx create-react-app



    Package.json -> will have all the configurations and dependencies


    Npm-node package manager
    Npx- executor


    online editor - >.  lex- explorer-online editor


    State is a JavaScript object used to manage the data of an application

    States are mutable
    They are reserved for interactivity. The component's event handlers may update the state and trigger a UI update
    The state will be set with a default value when component mounts and will mutate in time based on user events generated

. Props are immutable – The child component cannot modify the props. However, when parent component updates the data that is passed as props then the Child component gets updated props.

            2. Whenever props are updated the component gets re-rendered and displays the latest value in the UI.

    Every component will have following phases in its Lifecycle:

    Mounting phase - when the component is mounted to DOM tree,fetching the initial data
    Updating phase - when component is being updated with new state, new  props are being received, controlling the rendering
    Unmounting phase - destroying component from DOM tree, garbage collection

    As discussed previously, API calls should be made after the component mounts using useEffect hook​​​​​​​

axios.get()
        axios.post()
        axios.put()
        axios.delete()
        axios.patch()
        axios.options()

    A component can be unmounted from DOM using ReactDOM.unmountComponentAtNode()


    Forms
    Controlled-> state is controlled by js, useState()Hackers37
    Uncontrolled -> state is not controlled by js,   userref()

    Dd



    For router ->
            import ReactDOM from 'react-dom’;


    Controlled components
    The input form elements whose values are controlled by React are called a controlled component.


    Uncontrolled components:
    The input element whose data is handled by the DOM.  You can use a ref to access the input's DOM node and extract its value.


    useRef hook
    Refs can be created using useRef hook and assigned to input elements. The value can be accessed using ref.current.value as shown below:




    useParams hook is used access the route parameters.

    useNavigate hook is used to configure routes programmatically




    Create web apps with reusable components

    Handle data in components using props and states

    Implement life cycle hooks on components

    Perform asynchronous calls to handle CRUD operations

    Create and handle forms

    Create a single page application using routing

    Create web application using Redux

    Debug React and Redux Application


            Ah

    h









    explain child nodes?


}
