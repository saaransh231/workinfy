package com.company;

public class sql Sql talk

        SELECT * FROM TK_STORE_DETAILS where store_region=‘US-East’;
        SELECT store_name, store_number, store_url, latitude, longitude, store_region FROM TK_STORE_DETAILS;
        select * from TK_POD;
        select * from TK_SERVER_TK_CHANNEL_STORERECEIPT order by creation_date Desc;
        select * from TK_CLIENT_RECEIVE_RECEIPT order by creation_date Desc;
        select * from TK_CLIENT_SEND_RECEIPT order by creation_date Desc;
        select * from TK_CLIENT_SEND_RECEIPT where message_id=‘C5D53D2E-1FAA-4A3F-991B-30361148B3BF’;
        select * from TK_USER_PREFERENCE;
        select * from TK_USER_STORE_CHANNEL;
        select * from TK_SERVER_RECEIPT where store_number=‘R210’;
        select * from TK_SERVER_RECEIPT order by creation_date Desc;
        select * from TK_CHANNEL_STORE where channel_id=‘429’;
        delete from TK_USER_PREFERENCE where prs_id=‘2320215610’;
        select * from TK_USER_PREFERENCE where prs_id=‘2320215610’;
        INSERT INTO TK_USER_PREFERENCE (prs_id, icon_id) VALUES (“35435”, “5");
        select * from TK_USER_PREFERENCE;
        SELECT * FROM TK_USER_ICON;
        select * from TK_CHANNEL_STORE;
        select * from TK_USER_GROUP_STORE where group_id in (2700991406);
        select * from TK_CLIENT_RECEIVE_RECEIPT order by creation_date Desc;
        select * from TK_CHANNEL_STORE where store_number=‘R231’;
        SELECT TUSC.prs_id, TUSC.device_id, TUSC.session_type, TUP.first_name, TUP.last_name, TUP.email, TUI.icon_hash, TUI.icon_value
        FROM TK_USER_STORE_CHANNEL TUSC, TK_USER_PREFERENCE TUP, TK_USER_ICON TUI
        WHERE TUSC.prs_id = ‘2320215610’  AND
        TUSC.STORE_NUMBER=‘R240’ AND  TUSC.status = 1 and TUSC.channel_id = ‘1501’;

        https://quip-apple.com/30NLAf7FNmK8



        -Denv=WEST2_AWSQA

        /Users/saaransh.shaw/git/TalkServiceAutomation/src/resource/certificate/certificate.p12

        {
}
