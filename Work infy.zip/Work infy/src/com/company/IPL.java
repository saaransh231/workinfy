package com.company;

public class IPL {
    ​
            ​
    Apple​
    Project: Retail Product Catalog​
    It is an iOS  application used by Apple Retail Store for storing and handling all the details of apple products and stores while purchasing/adding to cart.​
    With 4 services Product Catalog Service, Product Service Nextgen, Data Integration Service, Data Transformation service for different purposes we had to provide backend support for UI.​
            ​
    Responsibilities​
    Worked on business layer mainly worked on Product Catalog service.​
    Updated rest apis (get/stores, get/product) ​
    Found bugs in Data transformation service that processes and transforms the feeds​
.Testing of All the rest apis in postman locally and debugging.​
    Wrote unit tests using junit and Mockito.​
            ​
    Tools & Technologies ​
    Spring, Spring boot , Git, Rest api, Cassandra Db, Java 11, Docker,  Xcode.​
    Duration​
    Jun 2022 - Present




    Ipl Dashboard App​
​
    Application with a simple Ui with tabs which gives report of all the ipl teams, matches played, win/loss percentage and complete statistics.​
            ​
    Responsibilities​
​
    Developed backend using Spring Boot., Maven. Created model classes of Teams and Match and apis for fetching details, displaying Teams/Match data,​
    Using in memory DB and getting all the resource data from  Kaggle community data centre.​
    Developed Front end using ReactJs, used functional components and react hooks.​
    Used from react-router-dom for creating link between match details and teams details page.​
    Tested all the apis in Postman​
    Created build file and uploaded it in elastic bean stalk (AWS)​
            ​
            ​
    Tools & Technologies: ​
            ​
    Spring Initializer, Spring Boot, java11, PostMan, Maven, Aws, ReactJS
}
