package com.company;

public class d {
    rdar://86726662 (TTL for rpc_audits and rps_changed_parts)

    Add TTL (via RTP) for both the tables
    rpc_audits -> 6 months
    rps_changed_parts -> 6 months

    https://github.pie.apple.com/retail-product-catalog/product-data-transformation-service/pull/1017/filesr rpc_audits and rps_changed_parts)



            86400 seconds (one day). Use time-to-live (TTL) to expire data in a column or table. Columns and tables support an optional expiration period called TTL (time-to-live); TTL is not supported on counter columns.


    Cut below branch from develop

    Branch Name :  rdar_86726662_TTLforrpc_audits_and_rps_changed_parts

    Git checkout develop
    Git pull
— pull all the changes from develop branch —
    Git pull — it will always pull all the latest changes on that branch

    git checkout rdar_86726662_TTLforrpc_audits_and_rps_changed_parts

—————
    command:
    Git status
————— what changes you have made
    See the difference
    Git diff
            (All the differences)
    Git diff <file path>
————————
    git add .
    git commit -m "rdar://86726662 (TTL for rpc_audits and rps_changed_parts)"

    Push your changes to ur branch.
    Git push




    rpc.audit.ttl.seconds=155520000

            operationalConfig.getLong("rpc.changedpart.ttl.seconds", 5678987));

    @Query("insert into rps_health (key) values(:key) using TTL :ttl")
    public void insertOne(@Param("key") int key, @Param("ttl") int ttl);


    public int getTtlForN91Table() {
        return (int) TimeUnit.DAYS.toSeconds(RealTimePropertyInstance.getLong("campaign.feed.content.ttl.days", 2));
    }
    updateTask

Mockito.when(operationalConfig.getString("commplatform.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION);


    etLong(A3TOKEN_IDMS_APP_ID, 148541L)).thenReturn(148541L);
//        Mockito.when(operationalConfig.getLong(RCI_A3_OTHER_APP_ID, 4237L)).thenReturn(4237L);
//        Mockito.when(operationalConfig.getLong(RCI_A3_CONTEXT_VERSION, 3L)).thenReturn(3L);

        Mockito.when(operationalConfig.getLong(A3TOKEN_IDMS_APP_ID, 148541L)).thenReturn(148541L);
//        Mockito.when(operationalConfig.getLong(RCI_A3_OTHER_APP_ID, 4237L)).thenReturn(4237L);
//        Mockito.when(operationalConfig.getLong(SKYWALK_A3_CONTEXT_VERSION, 3L)).thenReturn(3L);

        Mockito.when(operationalConfig.getLong(IDMS_APP_ID, 148541L)).thenReturn(148541L);
        Mockito.when(operationalConfig.getString(IDMS_APP_PWD, "")).thenReturn("");
        Mockito.when(operationalConfig.getString("ssp.service.url", "")).thenReturn("");
        Mockito.when(operationalConfig.getString("ssp.auth.serviceName", "AuthenticationService")).thenReturn("AuthenticationService");
        Mockito.when(operationalConfig.getString("ssp.auth.operationName", "authenticate")).thenReturn("authenticate");
        Mockito.when(operationalConfig.getString("ssp.auth.environment", "DEV")).thenReturn("DEV");
        Mockito.when(operationalConfig.getString("ssp.auth.clientVersion", "2.0")).thenReturn("2.0");
        Mockito.when(operationalConfig.getString("ssp.auth.serviceVersion", "2.0")).thenReturn("2.0");

        Mockito.when(espTokenService.generateAuthToken(any())).thenReturn(Optional.of(ESP_TOKEN));
}

    @Test
    public void testGetRCIAuthenticationEspToken() throws Exception {
        Mockito.when(operationalConfig.getString("rci.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION);

        String token = authTokenServiceFactory.generateToken(Enums.AuthDestination.RCI);

        Assert.assertNotNull(token);
        Assert.assertEquals(ESP_TOKEN, token);
        Mockito.verify(espTokenService, Mockito.times(1)).generateAuthToken(any());
        Mockito.verify(a3TokenService, Mockito.never()).generateA3Token(any());
    }

    @Test
    public void testGetCommPlatformAuthenticationEspToken() throws Exception {
        Mockito.when(operationalConfig.getString("commplatform.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION);

        String token = authTokenServiceFactory.generateToken(Enums.AuthDestination.COMM_PLATFORM);

        Assert.assertNotNull(token);
        Assert.assertEquals(ESP_TOKEN, token);
        Mockito.verify(espTokenService, Mockito.times(1)).generateAuthToken(any());
        Mockito.verify(a3TokenService, Mockito.never()).generateA3Token(any());
    }

    @Test
    public void testGetRCIAuthenticationA3Token() throws Exception {
        Mockito.when(operationalConfig.getString("rci.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION_A3_TOKEN);
        Mockito.when(a3TokenService.generateA3Token(any())).thenReturn(SKYWALK_A3_TOKEN);

        String token = authTokenServiceFactory.generateToken(Enums.AuthDestination.RCI);

        Assert.assertNotNull(token);
        Assert.assertEquals(SKYWALK_A3_TOKEN, token);
        Mockito.verify(a3TokenService, Mockito.times(1)).generateA3Token(any());
        Mockito.verify(espTokenService, Mockito.never()).generateAuthToken(any());
    }

    @Test
    public void testGetSkywalkAuthenticationEspToken() throws Exception {
        Mockito.when(operationalConfig.getString("skywalk.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION);

        String token = authTokenServiceFactory.generateToken(Enums.AuthDestination.SKYWALK);

        Assert.assertNotNull(token);
        Assert.assertEquals(ESP_TOKEN, token);
        Mockito.verify(espTokenService, Mockito.times(1)).generateAuthToken(any());
        Mockito.verify(a3TokenService, Mockito.never()).generateA3Token(any());
    }

    @Test
    public void testGetSkywalkAuthenticationA3Token() throws Exception {
        Mockito.when(operationalConfig.getString("skywalk.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION_A3_TOKEN);
        Mockito.when(a3TokenService.generateA3Token(any())).thenReturn(RCI_A3_TOKEN);

        String token = authTokenServiceFactory.generateToken(Enums.AuthDestination.SKYWALK);
        Assert.assertNotNull(token);
        Assert.assertEquals(RCI_A3_TOKEN, token);
        Mockito.verify(a3TokenService, Mockito.times(1)).generateA3Token(any());
        Mockito.verify(espTokenService, Mockito.never()).generateAuthToken(any());
    }
̄
@Test
public void testGetAuthenticationTokenEspTokenException() throws Exception {
        Mockito.when(operationalConfig.getString("skywalk.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION);
        Mockito.when(espTokenService.generateAuthToken(any())).thenThrow(Mockito.mock(ServiceException.class));

        String token = authTokenServiceFactory.generateToken(Enums.AuthDestination.SKYWALK);
        Assert.assertNull(token);
        Mockito.verify(espTokenService, Mockito.times(1)).generateAuthToken(any());
        }

@Test
public void testGetAuthenticationTokenA3TokenException() throws Exception {
        Mockito.when(operationalConfig.getString("skywalk.ssp.auth.token.type", APPLICATION_A3_TOKEN)).thenReturn(APPLICATION_A3_TOKEN);
        Mockito.when(a3TokenService.generateA3Token(any())).thenThrow(Mockito.mock(AppToAppAuthenticationException.class));

        String token = authTokenServiceFactory.generateToken(Enums.AuthDestination.SKYWALK);
        Assert.assertNull(token);
        Mockito.verify(a3TokenService, Mockito.times(3)).generateA3Token(any());
        }
        }

        when(operationalConfig.getInt(Mockito.any(String.class), Mockito.any(Integer.class))).thenReturn(30000);

        rpc.audit.ttl.seconds=155520000
        rpc.changedpart.ttl.seconds=155520000

        }
