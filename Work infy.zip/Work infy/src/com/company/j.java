package com.company;

public class j Meter

        https://quip-apple.com/abT9AvrYuHRq

        https://quip-apple.com/isWBAwsPGRha

        https://quip-apple.com/JonPAgflo8Km#temp:C:IZb78642b6c5836461faa762cd98


        POST https://walker-uat-usspk05.apple.com/log


        Learn to run performance tests with Jmeter.  Validate multiple web socket connections for non admin users

        Hands on experience of performance script development

        - Ability to think through performance test scenarios based on application

        . Ability to analyse performance test results and provide insights

        - Ability to create huge test data in the shortest possible time

        - Experience of performance testing life cycle

        - Hands on experience of JMeter for UI, API

        - JMeter for API testing

        - Experience of API testing-Rest API

        - Analysis of performance report to figure out improvement area



        Did performance testing of our Application on jmter using jmx file, tested all the rest and and WebSocket
        Apis, with theadcounts of 5,10,15,20,25,30, and  csv file data. Configuring the required path, http headers and
        updated thread schedule. Final reporting of throughput, errors, request and response messages from
        aggregate report and view result tree and deep analysis in splunk logs were performed.


        spring.jpa.hibernate.ddl-auto=update
        spring.datasource.url=jdbc:mysql://localhost:3306/
        spring.datasource.username=root
        spring.datasource.password=Hackers37!

        spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver




        /apache-jmeter-5.4.1/bin
        sh jmeter -n -t <path_to>/JMX_FILE_NAME.jmx -l /<path_to>/DASHBOARD_REPORT_FILE_NAME.jtl -e -o <path_to>/reports/DASHBOARD_REPORT_FOLDER_NAME



        /apache-jmeter-5.4.1/bin sh jmeter -n -t /Users/saaransh.shaw/jmeterprojects2/walker-jmeter/WalkerTestDynamicUUID.jmx -l /Users/saaransh.shaw/jmeterprojects2reports/DASHBOARD_REPORT_FILE_NAME.jtl -e -o jm -l




        Splunk
        Here is the url for non prod ->
        https://splunk-ist-test.rno.apple.com/en-US/app/search/search?q=search%20index%3Djtalk_walk[…]658240068.1378718_3E8EED49-1DF0-46A6-BEFC-40B35FFB56DD

        splunk for prod->

        https://splunk-ist.corp.apple.com/en-US/app/search/search?q=
        search%20index%3Djtalk_walker[…]sid=1658240170.5889_1C8A73E4-C7A2-48FA-8D2E-0D43FDDF7FD2
        https://splunk-ist-test.rno.apple.com/en-US/app/search/search?q=search%20index%3Djtalk_walk[…]658240068.1378718_3E8EED49-1DF0-46A6-BEFC-40B35FFB56DD
        8:09
        And here is the url for prod with query
        i am able get all the tps values only
        https://splunk-ist.corp.apple.com/en-US/app/search/search?q=search%20index%3Djtalk_walker[…]sid=1658240170.5889_1C8A73E4-C7A2-48FA-8D2E-0D43FDDF7FD2


        Pt->
        index=jtalk_walker k8s_cluster="jtalk-pt-cluster-uswest2" | spath logger  | search logger="reactor.netty.http.server.AccessLog" NOT(*health)  | rex field=message "(?<url>uri.[^,]+)"  | timechart span=1m count
        index=jtalk_walker k8s_cluster="jtalk-pt-cluster-uswest2" | spath logger  | search logger="reactor.netty.http.server.AccessLog" NOT(*health)    | rex field=message "(?<url>uri.[^,]+)"  | rex field=message "(?<duration>duration.[^,]+)"  | eval duration=replace(duration,"duration=","") |  chart avg(duration), min(duration), max(duration), perc90(duration), perc95(duration) count by url
        {"timestamp":"2022-09-07T12:20:47,699Z","level":"INFO","thread":"reactor-http-epoll-4","message":"method=PUT, uri=/users/channel/leave, status=200, duration=84, accessDateTime=2022-09-07T12:20:47.614844169Z[GMT], user=-, contentLength=5, remoteAddress=/100.120.18.87:65201 ","logger":"reactor.netty.http.server.AccessLog”}

        As discussed below are the tests we need to run going forward to wrap up the PT testing for NPI.
        Please run the below tests.
        For each test I would like to see 2 reports.
        1. A test where there are more errors, this is a breaking point.
        2. A test where the errors are less than 1%. The thread count for this should be lower than the test 1.

        You can first run the tests multiple times with small time to find the correct thread count that can give above 2 results.
        Please only send the final 2 results for each test. Final tests on the report should run for about 20mns.
        Disable all the summary reports before you run the tests and run using only command line.
        Test 1:
        get users/qrCode
        get /store/qr-code
        POST users/qrCode
        Put users/qrCode
        Test 2:
        /users/store
        /users/active-channel
        /users/channel-name
        /users/region
        /channel-set
        /stores-ws/channels/
        Test 3:
        /users/preference
        /users/preference/viplist
        /users/preference/store-users
        /users/preference/store/join
        Test 4:
        /users/channel/leave
        /users/store/joinn/channelID
        /images-websocket{
}
